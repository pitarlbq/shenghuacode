alter table UserCompany add RoleID int null
GO